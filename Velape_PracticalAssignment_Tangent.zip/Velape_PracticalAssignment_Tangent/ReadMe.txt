Preconditions 
Make sure Java Jdk and Apache maven environment variables are set in your machine

Run from cmd prompt
Option 1
Go to your Maven Project location and open command prompt

mvn clean eg C:\Users\velapem\IdeaProjects\Velape_PracticalAssignment_Tangent>mvn clean
mvn install eg C:\Users\velapem\IdeaProjects\Velape_PracticalAssignment_Tangent>mvn install
mvn test eg C:\Users\velapem\IdeaProjects\Velape_PracticalAssignment_Tangent>mvn test


Running in windows OS

Option 2
Open the testRunner
Right click anywhere inside the page
Click on Run 'TestRunner'

Option 3
Open RiseAppCRUD.feature
Right click at the botton last line
Click on Run 'Feature: RiseAppCRUD'