package testRunner;

//Velape Makwarimba
//Practical Assignment
//Tangent Solutions

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features ="Features/RiseAppCRUD.feature",
        glue="stepDefinitions",
        plugin = { "pretty" },
        monochrome = true)
public class TestRunner
{
}
