package stepDefinitions;

import io.cucumber.java.en.*;
import  pages.BaseTest;

//Velape Makwarimba
//Practical Assignment
//Tangent Solutions

public class RiseAppCRUDsteps extends BaseTest{
    BaseTest bTest = new BaseTest();

    @Given("I Login to RiseApp portal")
    public void i_login_to_rise_app_portal() {
        bTest.OpenHomepage();
    }
    @Given("I have entered {string} as a username")
    public void i_have_entered_as_a_username(String username) {
        PopulateUsername(username);
    }
    @Given("I have entered {string} as a password")
    public void i_have_entered_as_a_password(String password) {
        PopulatePassword(password);
    }
    @When("I click Login button")
    public void i_click_login_button() {
        ClickLoginButton();
    }
    @Then("I should see the dashboard")
    public void i_should_see_the_dashboard() {
        VerifyDashboard();
    }
    @And("close browser")
    public void close_browser() {
        CloseBrowser();
    }
    @Given("I click on the menu button")
    public void i_click_on_the_menu_button() {
        ClickMenuButton();
    }
    @Given("I click on Lookups")
    public void i_click_on_lookups() {
        ClickLookUpLink();
    }
    @When("I click on nationalities")
    public void i_click_on_nationalities() {
        ClickNationalitiesLink();
    }

    @Then("I should see the nationalities dashboard")
    public void i_should_see_the_nationalities_dashboard() {
        VerifyNationalitiesDashboard();
    }

    @Given("I click on the add nationality button")
    public void i_click_on_the_add_nationality_button() {
        ClickMenuButton(); ClickLookUpLink(); ClickNationalitiesLink(); AddNationality();
    }
    @Given("I enter {string} in name field")
    public void i_enter_in_name_field(String name) {
        PopulateName(name);
    }
    @Given("I enter {string} in Description field")
    public void i_enter_in_description_field(String descrip) {
        PopulateDescription(descrip);
    }
    @When("I click on save button")
    public void i_click_on_save_button() {
        ClickSaveButton();
    }

    @Given("I click on the filter list of date nationality button")
    public void i_click_on_the_filter_list_of_date_nationality_button() {
        ClickMenuButton(); ClickLookUpLink(); ClickNationalitiesLink();  FilterListData();
    }
    @When("I click on filter button")
    public void i_click_on_filter_button() {
        ClickFilterButton();
    }
    @When("I click on name record")
    public void i_click_on_name_record() {
        ClickNameRecord();
    }
    @When("I click on back button")
    public void i_click_on_back_button() {
        ClickBackButton();
    }

    @When("I click on edit button")
    public void i_click_on_edit_button() {
        ClickEditButton();
    }
    @When("i clear the name field")
    public void i_clear_the_name_field() {
        ClearNameField();
    }
    @When("I enter the {string} in name field")
    public void i_enter_the_in_name_field(String edtName) {
        PopulateNameField(edtName);
    }
    @When("i clear the description field")
    public void i_clear_the_description_field() {
        ClearDescField();
    }
    @When("I enter the {string} in description field")
    public void i_enter_the_in_description_field(String edtDesc) {
        PopulateDescField(edtDesc);
    }
    @When("I click on delete record")
    public void i_click_on_delete_record() {
        DeleteRecord();
    }
    @Then("I click on RiseApp logo")
    public void i_click_on_rise_app_logo() {
        ClickRiseAppLogo();
    }
    @Then("I should see the homepage")
    public void i_should_see_the_homepage() {
        VerifyHomePage();
    }
}