package pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.concurrent.TimeUnit;

//Velape Makwarimba
//Practical Assignment
//Tangent Solutions


public class BaseTest {

    private static WebDriver driver;

    public void OpenHomepage()
    {
        //System.setProperty("webdriver.chrome.driver","C:\\Users\\velapem\\Documents\\vSoft\\drivers\\chromedriver.exe");
        String path = System.getProperty("user.dir");
        System.setProperty("webdriver.chrome.driver",path+"\\drivers\\chromedriver.exe");

        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://staging.riseapp.co.za/");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
        driver.findElement(By.id("id_username")).sendKeys("yellowgrass@riseapp.co.za");
        driver.findElement(By.id("id-password")).sendKeys("adminadmin123");
        ClickLoginButton();
        VerifyDashboard();
    }

    public  void PopulateUsername(String txt)
    {
        driver.findElement(By.id("id_username")).sendKeys("yellowgrass@riseapp.co.za");
    }
    public  void PopulatePassword(String txt)
    {
         driver.findElement(By.id("id-password")).sendKeys("adminadmin123");
    }

    public void VerifyDashboard()
    {
        boolean status = driver.findElement(By.xpath("//a[contains(text(),'Home')]")).isDisplayed();
        Assert.assertEquals(true,status);
    }

    public void CloseBrowser() {
        driver.quit();
    }

    public void ClickLoginButton() {
        driver.findElement(By.xpath("//body/div[2]/div[1]/div[3]/section[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/button[1]")).click();
    }

    public void VerifyHomePage()
    {
        WebDriverWait wait = new WebDriverWait(driver,15);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Home')]")));
        boolean status = driver.findElement(By.xpath("//a[contains(text(),'Home')]")).isEnabled();
        Assert.assertEquals(true,status);

    }
    public void ClickMenuButton() {
        driver.findElement(By.xpath("//body/nav[1]/div[1]/div[2]/div[1]/ul[1]/li[1]/a[1]/i[1]")).click();
    }

    public void ClickLookUpLink() {
        driver.findElement(By.xpath("//span[contains(text(),'Lookups')]")).click();
    }

    public void ClickNationalitiesLink() {
        driver.findElement(By.xpath("//a[contains(text(),'Nationalities')]")).click();
    }

    public void VerifyNationalitiesDashboard()
    {
        driver.findElement(By.xpath("//h3[contains(text(),'Nationalities')]")).click();
    }

    public void AddNationality() {
        driver.findElement(By.xpath("//span[contains(text(),'Add Nationality')]")).click();
    }

    public  void PopulateName(String name)
    {
        driver.findElement(By.id("id_name")).sendKeys("VPracAssignment");
    }

    public  void PopulateDescription(String desc)
    {
        driver.findElement(By.id("id_description")).sendKeys("The BDD tech practical assessment");
    }
    public void ClickSaveButton() {
        driver.findElement(By.name("save")).click();
    }

    public void FilterListData() {
        driver.findElement(By.id("table-filter-helper-search-link")).click();
    }
    public  void PopulateNameContains(String desc)
    {
        driver.findElement(By.id("id_name")).sendKeys("VPracAssignment");
    }

    public void ClickFilterButton() {
        driver.findElement(By.id("filter_button")).click();
    }

    public void ClickNameRecord()
    {
        ScrollToName();
        // driver.findElement(By.xpath("//a[contains(text(),'VPracAssignment')]")).click();
        driver.findElement(By.linkText("VPracAssignment")).click();
    }
    public void ClickBackButton() {
        driver.findElement(By.xpath("//span[contains(text(),'Back')]")).click();
    }

    public void ClickEditButton() {
        driver.findElement(By.xpath("//span[contains(text(),'Edit')]")).click();
    }

    public void ClearNameField() {
        driver.findElement(By.id("id_name")).clear();
    }

    public void ClearDescField() {
        driver.findElement(By.id("id_description")).clear();
    }

    public  void PopulateNameField(String txtname)
    {
        driver.findElement(By.id("id_name")).sendKeys("VPracAssignmentEdit");
    }
    public  void PopulateDescField(String txtdesc)
    {
        driver.findElement(By.id("id_description")).sendKeys("The BDD tech practical assessment edit");
    }
    public void DeleteRecord() {
        ScrollToElement();
        driver.findElement(By.xpath("//tbody/tr[1]/td[4]/a[1]/i[1]")).click();
        driver.findElement(By.xpath("//body/div[3]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/form[1]/button[1]")).click();
    }
    public void ScrollToElement()
    {
        WebElement element = driver.findElement(By.xpath("//tbody/tr[1]/td[4]/a[1]/i[1]"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
    }
    public void ScrollToName()
    {
        //WebElement element = driver.findElement(By.xpath("//a[contains(text(),'VPracAssignment')]"));
        WebElement element = driver.findElement(By.linkText("VPracAssignment"));
       ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
    }
    public void ClickRiseAppLogo()
    {
        driver.findElement(By.xpath("//body/nav[1]/div[1]/div[1]/ul[1]/li[2]/a[1]/img[1]")).click();
    }
}